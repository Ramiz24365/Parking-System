const express=require('express')
const app=express()
require('dotenv').config()  /* <--callign .env file */
const parkingRouter=require('./routers/parking')
const mongoose=require('mongoose')
app.use(express.urlencoded({extended:false}))  /* <--break post method security for get the value from form */
const session=require('express-session')

mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)

app.use(session({
    secret:process.env.SECRET_KEY,
    resave:false,
    saveUninitialized:false,
   // cookie:{maxAge:1000*60*60*24}  /* <--set session for 1day and user do not require to login again and again since 1 day */ 
}))

app.use(parkingRouter)
app.use(express.static('public'))
app.set('view engine','ejs')

app.listen(process.env.PORT,()=>{console.log(` Ramiz server is running on port ${process.env.PORT}`)})