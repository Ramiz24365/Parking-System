const { request } = require('express')
const Reg=require('../models/reg')
const bcrypt=require('bcrypt')


exports.loginapage=(req,res)=>{
    res.render('login.ejs',{massage:""})
}
exports.registerpage=(req,res)=>{
    res.render('registration.ejs',{massage:''})
}
exports.register=async(req,res)=>{
    //console.log(req.body)
    const{user,pass}=req.body
    const usercheck=await Reg.findOne({username:user}) /* <--check username from table */
    if(usercheck==null){
        const convertPass=await bcrypt.hash(pass,10)
        const record= new Reg({username:user,password:convertPass}) /* <--insert data into table with mapping  */
        record.save()
        //console.log(record)
        res.render('registration.ejs',{massage:`${user}  Your account is Successfully Created`})
    }
    else{
        res.render('registration.ejs',{massage:`${user}  User is already registered with us`})
    }
}
exports.logincheck=async(req,res)=>{
    const{user,pass}=req.body
    const record= await Reg.findOne({username:user})  /* <--check username into table */    
    if(record!==null){
        const passwordcompare=await bcrypt.compare(pass,record.password)/* <--check bycrypt user password from table  */
        //console.log(passwordcompare)
        if(passwordcompare){
            req.session.isAuth=true /* ---trigger for creating session after all info are correct*/
            req.session.loginname=user
            res.redirect('/parking')
        }
        else{
            res.render("login.ejs",{massage:"Wrong credentials"})
        }
    }
    else{
        res.render("login.ejs",{massage:"Wrong credentials"})
    }
}
exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}