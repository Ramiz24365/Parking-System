const Parking=require('../models/parking')

exports.parkingpage= async(req,res)=>{
    //console.log(req.session)
    const loginname=req.session.loginname
    const record=await Parking.find()
    res.render('parking.ejs',{loginname,record})
}
exports.parkingaddform=(req,res)=>{
    const loginname=req.session.loginname
    res.render('parkingform.ejs',{loginname,massage:''})
}
exports.vehicleadd=(req,res)=>{
    //console.log(req.body)
    const{vno,vtype}=req.body
    const vtime=new Date()
    const record=new Parking({vno:vno,vtype:vtype,vin:vtime})
    record.save()
    //console.log(record)
    const loginname=req.session.loginname
    res.render('parkingform.ejs',{loginname,massage:"successfully added"})
}
exports.parkingupdate=async(req,res)=>{
    //console.log(req.params.id)
   const id=req.params.id
   let outTime=new Date()
   const record= await Parking.findById(id) /* <--find date from table */
   //console.log(record)
   let consumeTime=(outTime-record.vin)/(1000*60*60) /* <---calculate consume time and convert it into hours */
    //console.log(consumeTime)
   let amount=null
   if(record.vtype=='2w'){  /* start<---set the amount based on vehicle type and set charged based on consumetime */
    amount=consumeTime*30
   }else if(record.vtype=='3w'){
    amount=consumeTime*50
   }
   else if(record.vtype=='4w'){
    amount=consumeTime*50
   }
   else if(record.vtype=='hw'){
    amount=consumeTime*50
   }
   else if(record.vtype=='lw'){
    amount=consumeTime*50
   }
   else{
    amount=consumeTime*60
   }                          /*< ----end<---set the amount based on vehicle type and set charged based on consumetime*/
   await Parking.findByIdAndUpdate(id,{vout:outTime,amount:Math.round(amount),status:'OUT'}) /* <---update vehicle outitme when status is update to Out*/
   res.redirect('/parking')
}

exports.parkingprint=async(req,res)=>{
    //console.log(req.params.id)
    const id=req.params.id
    const record=await Parking.findById(id)
    res.render('printpage.ejs',{record})
}

exports.parkingdelete=async(req,res)=>{
    //console.log(req.params.id)
    const id=req.params.id
    await Parking.findByIdAndDelete(id)
    res.redirect("/parking")
}