const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const parkingc=require('../controllers/parkingcontroller')

/* start<--middleware function for handle login activity and user do not direct access page without login */
function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }
    else{
        res.redirect("/")
    }
}
/* end<--middleware function for handle login activity and user do not direct access page without login */


router.get('/',regc.loginapage)
router.get('/registeration',regc.registerpage)
router.post('/registeration',regc.register)
router.post('/',regc.logincheck)
router.get('/parking',handlelogin,parkingc.parkingpage)
router.get('/logout',regc.logout)
router.get('/recordadd',parkingc.parkingaddform)
router.post('/recordadd',parkingc.vehicleadd)
router.get('/parkingupdate/:id',parkingc.parkingupdate)
router.get('/parkingprint/:id',parkingc.parkingprint)
router.get('/parkingdelete/:id',parkingc.parkingdelete)

module.exports=router
